var APP_DATA = {
  "scenes": [
    {
      "id": "0-12png",
      "name": "1.2.png",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        },
        {
          "tileSize": 512,
          "size": 4096
        }
      ],
      "faceSize": 2976,
      "initialViewParameters": {
        "yaw": 2.0748477514839845,
        "pitch": 0.6119981955389129,
        "fov": 1.307633212018712
      },
      "linkHotspots": [
        {
          "yaw": 0.9057223056188803,
          "pitch": 0.3251691507963024,
          "rotation": 0,
          "target": "1-4444jpg"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.37192835126552737,
          "pitch": -0.3399644815997629,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": 1.576076285800017,
          "pitch": 0.07450764420577194,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": 1.0086464207952233,
          "pitch": -0.6405171561860108,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": 0.9534562390038417,
          "pitch": -0.41869862053260753,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": 0.013322498661565874,
          "pitch": -0.570228437592716,
          "title": "Titleggfggfggrg",
          "text": "Text"
        }
      ]
    },
    {
      "id": "1-4444jpg",
      "name": "4444jpg",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        },
        {
          "tileSize": 512,
          "size": 4096
        }
      ],
      "faceSize": 2976,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 3.110807560624596,
          "pitch": 0.4670966288591547,
          "rotation": 0,
          "target": "0-12png"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.4775141082797578,
          "pitch": -0.12610038977553906,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.0698256119878824,
          "pitch": -0.5562807738666518,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": 0.9659063344932779,
          "pitch": 0.2162832767735523,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.43303653055026814,
          "pitch": 0.1526703821082993,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": 1.0446113579207879,
          "pitch": -0.4380223503889127,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.48186969462674156,
          "pitch": -0.23555320274427594,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.2080994858785452,
          "pitch": 0.08354377843186711,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.06563153121812704,
          "pitch": 0.15942397136285713,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.5952364001291262,
          "pitch": -0.2056387024242916,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.6332679908868428,
          "pitch": 0.20645658696487956,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.8316591876263271,
          "pitch": 0.2812266373272845,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -1.0235744606933306,
          "pitch": -0.15455156498563838,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": 0.04722347283435724,
          "pitch": 0.47668533388596757,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -1.0974324445378443,
          "pitch": -0.0062379515229480376,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.4713814228363482,
          "pitch": 0.6766033370284426,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": 0.5977725073337474,
          "pitch": 0.6003761772038896,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.9314810970483514,
          "pitch": 0.32084320441151526,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.6401448421875209,
          "pitch": 0.010391511260447572,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.6585222569382232,
          "pitch": -0.3637596026744081,
          "title": "Title",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
